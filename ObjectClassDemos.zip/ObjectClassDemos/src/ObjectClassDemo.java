//java.lang package
//all the classes are directly or indirectly inherited from the object class
//when we try to print the obj it will call the toString method
//we can just overrid the toString , hashcode , equals methods of the object class
import java.lang.*;
class MyClass
{
	public String toString()
	{
		return "This is the toString method";
	}
	public int hashCode()
	{
		return 100;
	}
	public boolean equal(Object o)
	{
		return this.hashCode() == o.hashCode();
	}
//	public void wait()
//	{
//		
//	}
}
class Child extends MyClass
{
	
}
public class ObjectClassDemo {

	public static void main(String[] args) 
	{
		Object obj = new Object();
		Object obj1 = new Object();
		obj=obj1;
		System.out.println(obj.equals(obj1));
		MyClass a = new MyClass();
		MyClass c = new MyClass();
		Child b = new Child();
		System.out.println(a.toString());
		System.out.println(obj);
		System.out.println(a.hashCode());
		System.out.println(a.equal(c));
		

	}

}
