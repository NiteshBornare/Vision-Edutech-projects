package com.visionedutech.bankapplication.service;

import java.util.Random;
import java.util.Scanner;

import com.visionedutech.bankapplication.model.Account;

public class BankServiceImpl implements BankService {

	Account ac = new Account();
	Scanner sc = new Scanner(System.in);

	@Override
	public void createBankAccount() {
		System.out.println("Enter your name");
		String name = sc.next();
		ac.setUser_name(name);
		System.out.println("Enter your address");
		String address = sc.next();
		ac.setUser_address(address);
		System.out.println("Enter your PAN");
		String pan_no = sc.next();
		ac.setPan_no(pan_no);
		System.out.println("Enter amount to deposite");
		int deposite = sc.nextInt();
		ac.setBalance(deposite);
		// generating random number using Random
		Random random = new Random();
		int accno = random.nextInt(1000000);
		ac.setAcc_no(accno);
		System.out.println("Your account created successfully and your account number is " + accno);

	}

	@Override
	public void viewAccountDetails() {
		System.out.println("Enter your account number");
		int userAccountNumber = sc.nextInt();
		if (ac.getAcc_no() == userAccountNumber) {
			System.out.println("Fetching the account details");
			System.out.println(ac.getAcc_no());
			System.out.println(ac.getUser_name());
			System.out.println(ac.getUser_address());
			System.out.println(ac.getPan_no());
			System.out.println(ac.getBalance());

			ac.toString();
		} else {
			System.out.println("Create Account First");
		}
	}

	@Override
	public void withdrawMoney() {

		// enter his account number
		System.out.println("Enter your account number");
		// accept that account number
		int accno = sc.nextInt();
		// if account number is same as the account number present in the object
		// {
		if (ac.getAcc_no() == accno) {
			// ask user to enter the amount which he wants to withdraw
			System.out.println("Enter the amount to withdraw");
			// accept that amount
			int debitAmt = sc.nextInt();
			// compare the entered amount with the amount available in your account and
			// allow to get
			// the money only if amt < balance
			int balance = ac.getBalance();
			if (debitAmt < balance) {
				// balance - amt
				balance = balance - debitAmt;
				System.out.println("amout withdrawl successfully and the available balance is : " + balance);

			}
			// if amt > bal then let user know the balance is insufficient
			else {
				System.out.println("insufficinet fund!!!");
			}

			// let user know amout withdrawl successfully and the available balance is :

			// }

		}
		// otherwise display message saying create your account first
		else {
			System.out.println("Create your account first");
		}
	}

	@Override
	public void depositMoney() {
		// enter account and verify it
		System.out.println("Enter your account number");
		Scanner sc = new Scanner(System.in);
		int accno = sc.nextInt();
		if (ac.getAcc_no() == accno) {
			System.out.println("Enter the amount which you wants to deposit");
			int creditAmt = sc.nextInt();
			int balance = ac.getBalance() + creditAmt;
			ac.setBalance(balance);
			System.out.println("amount deposited successfuly and the available balance is : " + balance);

		} else {
			System.out.println("Create your account first");
		}
		// ask user to enter the amount to deposit
		// add that amount to the balance
		// print the message saying amount deposited successfuly and the available
		// balance is :

	}

	@Override
	public void updateAccountDetails() {

		// enter account and verify it
		// enter account and verify it
		System.out.println("Enter your account number");
		Scanner sc = new Scanner(System.in);
		int accno = sc.nextInt();
		if (ac.getAcc_no() == accno) {
			boolean flag = true;
			while (flag) {
				// ask user to enter press 1 for name update and 2 for address update and 3 for
				// pan update
				System.out.println("Press 1 for name update");
				System.out.println("Press 2 for address update");
				System.out.println("Press 3 for pan update");
				System.out.println("Press 4 for Exit");
				int ch = sc.nextInt();
				switch (ch) {
				case 1:
					System.out.println("Enter the name which you want to update");
					String user_name = sc.next();
					ac.setUser_name(user_name);
					System.out.println("name updated successfully and the updated details are " + ac.getUser_name());
					break;
				case 2:
					System.out.println("Enter the address which you wants to update");
					String user_address = sc.next();
					ac.setUser_address(user_address);
					System.out.println(
							"Address updated successfully and the updated details are " + ac.getUser_address());
					break;
				case 3:
					System.out.println("Enter the pan no which you wnats to update");
					String user_pan = sc.next();
					ac.setPan_no(user_pan);
					System.out.println("Pan no updated successfully and pan details are " + ac.getPan_no());
					break;
				case 4:
					flag = false;
					break;

				default:
					System.out.println("Invalid choice !!!!!");
					break;
				}
			}
		} else {
			System.out.println("Create your account first");
		}

		// set the values to the acc obj according to the selection of user
		// in the last print the updated details
	}

}
