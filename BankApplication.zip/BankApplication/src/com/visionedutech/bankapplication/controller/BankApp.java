package com.visionedutech.bankapplication.controller;

import java.util.Scanner;

import com.visionedutech.bankapplication.service.BankService;
import com.visionedutech.bankapplication.service.BankServiceImpl;

public class BankApp {

	public static void main(String[] args) 
	{
		BankService bankService = new BankServiceImpl();
		boolean flag = true;
		while(flag)
		{
		System.out.println("press 1 for account creation");
		System.out.println("press 2 for view account");
		System.out.println("press 3 for withdraw money");
		System.out.println("press 4 for deposite money");
		System.out.println("press 5 for update details");
		System.out.println("press 6 for EXIT");
		
		Scanner sc = new Scanner(System.in);
		int ch = sc.nextInt();
		switch (ch)
		{
		case 1:
			bankService.createBankAccount();
			break;
		case 2:
			bankService.viewAccountDetails();
			break;
		case 3:
			bankService.withdrawMoney();
			break;
		case 4:
			bankService.depositMoney();
			break;
		case 5:
			bankService.updateAccountDetails();
			break;
		case 6:
			flag = false;
			break;
		default:
			System.out.println("Invalid choice");
			break;
		}

	}

}
}
